int TasksLength = 0;

#define task_type_void 0
#define task_type_string_buffer 1
#define task_params_length 10

int system_r = 237;
int system_g = 168;
int system_b = 71;

struct Task {
    int priority;
    int taskId;
    char ca1[100];
    int i1;

    // Function Ptrs
    int (*function)(int);
};

struct Task tasks[256];
int iparams[100] = {10};

void ProcessTasks() {
    int priority;
    int i = 0;

    priority = 5;
    while (priority >= 0) {
        i = mouse_possessed_task_id;
        if (left_clicked == TRUE &&
                mx > iparams[i * task_params_length + 0] &&
                mx < iparams[i * task_params_length + 0] + iparams[i * task_params_length + 2] &&
                my > iparams[i * task_params_length + 1] &&
                my < iparams[i * task_params_length + 1] + iparams[i * task_params_length + 3])
                break;

        for (i = 0; i < TasksLength; i++) {
            if (left_clicked == TRUE &&
                mx > iparams[i * task_params_length + 0] &&
                mx < iparams[i * task_params_length + 0] + iparams[i * task_params_length + 2] &&
                my > iparams[i * task_params_length + 1] &&
                my < iparams[i * task_params_length + 1] + iparams[i * task_params_length + 3]) {
                    tasks[mouse_possessed_task_id].priority = 0;
                    mouse_possessed_task_id = i;
                    tasks[i].priority = 2;
                    left_clicked = FALSE;
                }
        }

        priority--;
    }

    priority = 0;
    while (priority <= 5) {
        for (int i = 0; i < TasksLength; i++) {
            if (tasks[i].priority == priority) {
                tasks[i].function(tasks[i].taskId);
            }
        }

        priority++;
    }
}
int NullTask(int taskId) {
    return 0;
}

void CloseTask(int taskId) {
    tasks[taskId].function = &NullTask;
    iparams[taskId * task_params_length + 0] = 0;
    iparams[taskId * task_params_length + 1] = 0;
    iparams[taskId * task_params_length + 2] = 0;
    iparams[taskId * task_params_length + 3] = 0;
}

int ClearScreenTask(int taskId) {
    VBEInfoBlock* VBE = (VBEInfoBlock*) VBEInfoAddress;
    ClearScreen(system_r, system_g, system_b);
    char sakuya[] = "Running LigmabOS V1.2\0";
    DrawString(getArialCharacter, font_arial_width, font_arial_height, sakuya, 10, (VBE->y_resolution)-40, 0, 0, 0);

    return 0;
}

int DrawMouseTask(int taskId) {
    DrawMouse(mx, my, 240, 80, 120);
    DrawRect(mx, my, 5, 5, 0, 0, 0);

    return 0;
}

int HandleKeyboardTask(int taskId) {
    char* characterBuffer = tasks[taskId].ca1;
    int* characterBufferLength = &tasks[taskId].i1;

    char character = ProcessScancode(Scancode);

    if (backspace_pressed ==  TRUE) {
        characterBuffer[*characterBufferLength - 1] = "\0";
        (*characterBufferLength)--;
        backspace_pressed = FALSE;
        Scancode = -1;
    } else if (character != '\0') {
        characterBuffer[*characterBufferLength] = character;
        characterBuffer[*characterBufferLength + 1] = '\0';
        (*characterBufferLength)++;
        Scancode = -1;
    }

    DrawString(getArialCharacter, font_arial_width, font_arial_height, characterBuffer, 100, 100, 0, 0, 0);

    return 0;
}

int BootGreet(int taskId) {
    int* r = &iparams[taskId * task_params_length + 4];
    int* g = &iparams[taskId * task_params_length + 5];
    int* b = &iparams[taskId * task_params_length + 6];
    int closeClicked = DrawWindow(
        &iparams[taskId * task_params_length + 0],
        &iparams[taskId * task_params_length + 1],
        &iparams[taskId * task_params_length + 2],
        &iparams[taskId * task_params_length + 3],
        *r,
        *g,
        *b,
        &iparams[taskId * task_params_length + 9],
        taskId);

    int x = iparams[taskId * task_params_length + 0];
    int y = iparams[taskId * task_params_length + 1];
    int width = iparams[taskId * task_params_length + 2];
    int height = iparams[taskId * task_params_length + 3];

    if (closeClicked == TRUE)
        CloseTask(taskId);

    char GreetHeader[] = "Welcome to LigmabOS.\0";

    DrawString(getArialCharacter, font_arial_width, font_arial_height, GreetHeader, x + 40, y + 40, 0, 0, 10);

    return 0;
}


int ShellTask(int taskId) {
    int* r = &iparams[taskId * task_params_length + 4];
    int* g = &iparams[taskId * task_params_length + 5];
    int* b = &iparams[taskId * task_params_length + 6];
    int closeClicked = DrawWindow(
        &iparams[taskId * task_params_length + 0],
        &iparams[taskId * task_params_length + 1],
        &iparams[taskId * task_params_length + 2],
        &iparams[taskId * task_params_length + 3],
        *r,
        *g,
        *b,
        &iparams[taskId * task_params_length + 9],
        taskId);

    DrawRect(17, 35, 30, 5, 255, 140, 0);
    int x = iparams[taskId * task_params_length + 0];
    int y = iparams[taskId * task_params_length + 1];
    int width = iparams[taskId * task_params_length + 2];
    int height = iparams[taskId * task_params_length + 3];

    if (closeClicked == TRUE)
        CloseTask(taskId);

    char text[] = "Dark\0";
    char text1[] = "Light\0";

    char ProgramName[] = "Testing Application\0";

    DrawString(getArialCharacter, font_arial_width, font_arial_height, ProgramName, x + 10, y, 242, 243, 244);

    if (
        DrawButton(x + 50, y + 80, 80, 60, 240, 240, 240,
            text, 50, 100, 50, taskId
    ) == TRUE) {
        *r = 0;
        *g = 0;
        *b = 0;
    }

    if (
        DrawButton(x + 160, y + 80, 80, 60, 240, 240, 240,
            text1, 50, 50, 100, taskId
    ) == TRUE) {
        *r = 150;
        *g = 150;
        *b = 150;
    }

    return 0;
}

int SystemPrefs(int taskId) {
    int* r = &iparams[taskId * task_params_length + 4];
    int* g = &iparams[taskId * task_params_length + 5];
    int* b = &iparams[taskId * task_params_length + 6];
    int closeClicked = DrawWindow(
        &iparams[taskId * task_params_length + 0],
        &iparams[taskId * task_params_length + 1],
        &iparams[taskId * task_params_length + 2],
        &iparams[taskId * task_params_length + 3],
        *r,
        *g,
        *b,
        &iparams[taskId * task_params_length + 9],
        taskId);

    DrawRect(147, 35, 30, 5, 255, 140, 0);
    int x = iparams[taskId * task_params_length + 0];
    int y = iparams[taskId * task_params_length + 1];
    int width = iparams[taskId * task_params_length + 2];
    int height = iparams[taskId * task_params_length + 3];

    if (closeClicked == TRUE)
        CloseTask(taskId);

    char classic_bg[] = "Classic\0";
    char light_bg[] = "Light\0";
    char dark_bg[] = "Dark\0";
    char system_bg_colour[] = "System Background Colour:\0";

    char ProgramName[] = "System Settings\0";

    DrawString(getArialCharacter, font_arial_width, font_arial_height, ProgramName, x + 10, y, 242, 243, 244);


    DrawString(getArialCharacter, font_arial_width, font_arial_height, system_bg_colour, x + 20, y + 20, 286, 141, 71);

    if (
        DrawButton(x + 20, y + 45, 60, 20, 210, 210, 210,
            classic_bg, 50, 50, 100, taskId
    ) == TRUE) {
        system_r = 237;
        system_g = 168;
        system_b = 71;
    }

    if (
        DrawButton(x + 105, y + 45, 50, 20, 210, 210, 210,
            light_bg, 50, 50, 100, taskId
    ) == TRUE) {
        system_r = 180;
        system_g = 180;
        system_b = 180;
    }

    if (
        DrawButton(x + 185, y + 45, 50, 20, 210, 210, 210,
            dark_bg, 50, 50, 100, taskId
    ) == TRUE) {
        system_r = 0;
        system_g = 0;
        system_b = 0;
    }

    return 0;
}

int BallTask(int taskId) {
    int closeClicked = DrawWindow(
        &iparams[taskId * task_params_length + 0],
        &iparams[taskId * task_params_length + 1],
        &iparams[taskId * task_params_length + 2],
        &iparams[taskId * task_params_length + 3],
        0,
        63,
        189,
        &iparams[taskId * task_params_length + 9],
        taskId);
    
    if (closeClicked == TRUE)
        CloseTask(taskId);

    DrawRect(82, 35, 30, 5, 255, 140, 0);
    int x = iparams[taskId * task_params_length + 0];
    int y = iparams[taskId * task_params_length + 1];
    int width = iparams[taskId * task_params_length + 2];
    int height = iparams[taskId * task_params_length + 3];

    iparams[taskId * task_params_length + 5] += iparams[taskId * task_params_length + 7];
    iparams[taskId * task_params_length + 6] += iparams[taskId * task_params_length + 8];

    if (iparams[taskId * task_params_length + 5] + 10 > iparams[taskId * task_params_length + 2] ||
        iparams[taskId * task_params_length + 5] - 10 < 0)
        iparams[taskId * task_params_length + 7] = -iparams[taskId * task_params_length + 7];
    
    if (iparams[taskId * task_params_length + 6] + 10 > iparams[taskId * task_params_length + 3] ||
        iparams[taskId * task_params_length + 6] - 10 < 20)
        iparams[taskId * task_params_length + 8] = -iparams[taskId * task_params_length + 8];

    char ProgramName[] = "Bouncing Ball\0";

    DrawString(getArialCharacter, font_arial_width, font_arial_height, ProgramName, x + 10, y, 242, 243, 244);

    DrawCircle(x + iparams[taskId * task_params_length + 5], y + iparams[taskId * task_params_length + 6], 10, 230, 230, 230);

}

int TaskbarTask(int taskId) {
    VBEInfoBlock* VBE = (VBEInfoBlock*) VBEInfoAddress;
    int bottomline = (VBE->y_resolution)-40;
    DrawRect(0, 0, VBE->x_resolution, 40, 30, 30, 90);
    DrawRect(0, 40, VBE->x_resolution, 10, 40, 40, 120);

    int i = iparams[taskId * task_params_length + 4];

    char text[] = "TestApp\0";
    if (DrawButton(0, 0, 60, 40, 60, 220, 60, text, 250, 250, 250, taskId) == TRUE) {
    	tasks[TasksLength].priority = 0;
        tasks[TasksLength].taskId = TasksLength;
        tasks[TasksLength].function = &ShellTask;
        iparams[TasksLength * task_params_length + 0] = i * 60;
        iparams[TasksLength * task_params_length + 1] = i * 60;
        iparams[TasksLength * task_params_length + 2] = 300;
        iparams[TasksLength * task_params_length + 3] = 300;
        iparams[TasksLength * task_params_length + 4] = 0;
        iparams[TasksLength * task_params_length + 5] = 0;
        iparams[TasksLength * task_params_length + 6] = 0;
	    TasksLength++;
        iparams[taskId * task_params_length + 4]++;
    }

    char text2[] = "Ball\0";
    if (DrawButton(70, 0, 50, 40, 60, 60, 240, text2, 250, 250, 250, taskId) == TRUE) {
    	tasks[TasksLength].priority = 0;
        tasks[TasksLength].taskId = TasksLength;
        tasks[TasksLength].function = &BallTask;
        iparams[TasksLength * task_params_length + 0] = i * 60;
        iparams[TasksLength * task_params_length + 1] = i * 60;
        iparams[TasksLength * task_params_length + 2] = 300;
        iparams[TasksLength * task_params_length + 3] = 300;
        iparams[TasksLength * task_params_length + 4] = 0;
        iparams[TasksLength * task_params_length + 5] = 20;
        iparams[TasksLength * task_params_length + 6] = 30;
        iparams[TasksLength * task_params_length + 7] = 5;
        iparams[TasksLength * task_params_length + 8] = 5;
	    TasksLength++;
        iparams[taskId * task_params_length + 4]++;
    }

    char text3[] = "System\0";
    if (DrawButton(130, 0, 60, 40, 240, 60, 60, text3, 250, 250, 250, taskId) == TRUE) {
    	tasks[TasksLength].priority = 0;
        tasks[TasksLength].taskId = TasksLength;
        tasks[TasksLength].function = &SystemPrefs;
        iparams[TasksLength * task_params_length + 0] = i * 60;
        iparams[TasksLength * task_params_length + 1] = i * 60;
        iparams[TasksLength * task_params_length + 2] = 300;
        iparams[TasksLength * task_params_length + 3] = 300;
        iparams[TasksLength * task_params_length + 4] = 0;
        iparams[TasksLength * task_params_length + 5] = 20;
        iparams[TasksLength * task_params_length + 6] = 30;
	    TasksLength++;
        iparams[taskId * task_params_length + 4]++;
    }


}