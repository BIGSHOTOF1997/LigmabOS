#include "graphics.h"

int start() {
    VBEInfoBlock* VBE = (VBEInfoBlock*) VBEInfoAddress;

	mx = VBE->x_resolution / 2;
	my = VBE->y_resolution / 2;

	int taskId;

	char characterBuffer[1000] = "\0";
	char * characterBufferPointer = characterBuffer;
	int characterBufferLength = 0;

	// Strings below 61 characters pls

	base = (unsigned int) &isr1;
	base12 = (unsigned int) &isr12;

	tasks[TasksLength].priority = 0;
	tasks[TasksLength].function = &ClearScreenTask;
	TasksLength++;

	tasks[TasksLength].priority = 0;
	tasks[TasksLength].function = &TaskbarTask;
	tasks[TasksLength].taskId = TasksLength;
	iparams[TasksLength * task_params_length + 0] = 0;
	iparams[TasksLength * task_params_length + 1] = 0;
	iparams[TasksLength * task_params_length + 2] = VBE->x_resolution;
	iparams[TasksLength * task_params_length + 3] = 40;
	iparams[TasksLength * task_params_length + 4] = 1;
	TasksLength++;

	tasks[TasksLength].priority = 5;
	tasks[TasksLength].function = &HandleKeyboardTask;
	TasksLength++;

	tasks[TasksLength].priority = 5;
	tasks[TasksLength].function = &DrawMouseTask;
	TasksLength++;

	system_r = 237;
	system_g = 168;
	system_b = 71;

	// Greeting on Boot
	tasks[TasksLength].priority = 1;
	tasks[TasksLength].taskId = TasksLength;
	tasks[TasksLength].function = &BootGreet;
	iparams[TasksLength * task_params_length + 0] = 335;
	iparams[TasksLength * task_params_length + 1] = 200;
	iparams[TasksLength * task_params_length + 2] = 600;
	iparams[TasksLength * task_params_length + 3] = 500;
	iparams[TasksLength * task_params_length + 4] = 100;
	iparams[TasksLength * task_params_length + 5] = 180;
	iparams[TasksLength * task_params_length + 6] = 100;
	TasksLength++;
	iparams[taskId * task_params_length + 4]++;
	
	while(1) {

		InitialiseMouse();
		InitialiseIDT();


		ProcessTasks();

		Flush();


	}
}